'''ЗАДАЧА
Написать программу которая позволит читать и добалять данные из файла с заказами клиентов.
При добавлении новых данных программа должна проверять правильность ввода дынных'''

import re

def main_menu():
    print('ГЛАВНОЕ МЕНЮ\n1. Просомтр списка заказов\n2. Добавление данных')
    user_input = input('Введите команду-')
    if user_input == '1':
        mod_menu()
    elif user_input == '2':

    else:
        print('команда не распозанан')
        main_menu()

def mod_menu():
    print('Сколько записей вы хотите вывести?\n1. Все записи\n2. Последние 10\n3. последние 5')
    user_input = input('Введите команду-')
    if user_input == '1':
        select_data(0)
    elif user_input == '2':
        select_data(10)
    elif user_input == '3':
        select_data(5)
    else:
        print('команда не распозанан')
        mod_menu()


def select_data(limit):
    with open('data.txt', 'r') as file:
        strings = file.read().split('\n')
    if limit == 0:
        limit = len(strings)
    i = len(strings) - 1
    while i >= len(strings) - limit:
        print(strings[i])
        i -= 1

def add_data():
    with open('data.txt', 'r') as file:
        strings = file.read().split('\n')
    last_data = strings[-1]
    find_id = re.search(r'ID:\s\d+', last_data)
    id = find_id.group()
    user_email = input('Введите электронную почту')
    if not chek_email(user_email):


def chek_email(email):
    try:
        chek = re.search(r'[a-zA-Z0-9._]+@[a-z.]+.[a-z]{2,}', email)
        return True
    except:
        return False


main_menu()